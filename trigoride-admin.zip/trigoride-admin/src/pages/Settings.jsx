import React from "react";

const Settings = () => {
  return (
    <div>
      <h1 className="text-3xl font-bold mb-6">Settings</h1>
      <p>Application settings and configuration.</p>
    </div>
  );
};

export default Settings;
